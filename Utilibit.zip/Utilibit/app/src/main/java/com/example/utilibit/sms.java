package com.example.utilibit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class sms extends AppCompatActivity {
    Button send;
    EditText no,phnos,msg;
    private final int MY_PERMISSIONS_REQUEST_CODE = 1;

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode != MY_PERMISSIONS_REQUEST_CODE) {
            return;
        }
        boolean isGranted = true;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                isGranted = false;
                break;
            }
        }
        if (isGranted) {
            String n1=no.getText().toString();
            String n2=phnos.getText().toString();
            String n3=msg.getText().toString();
            for (int i=0;i<(Integer.parseInt(n1));i++){
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                PendingIntent pi=PendingIntent.getActivity(getApplicationContext(), 0, intent,0);

//Get the SmsManager instance and call the sendTextMessage method to send message
                SmsManager sms=SmsManager.getDefault();
                sms.sendTextMessage(n2,null,n3,pi,null);}
            Toast.makeText(getApplicationContext(), "Message Sent successfully!",
                    Toast.LENGTH_LONG).show();

        } else {
            Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();

        }
    }

    private void setPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_CODE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        send=(Button) findViewById(R.id.send);
        no=(EditText) findViewById(R.id.no);
        phnos=(EditText) findViewById(R.id.phnos);
        msg=(EditText) findViewById(R.id.msg);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(no.getText().toString()) || TextUtils.isEmpty(phnos.getText().toString()) || TextUtils.isEmpty(msg.getText().toString()) ){
                    Toast.makeText(sms.this,"Please Fill All Input Fields",Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    if (checkPermissions()) {
                        String n1=no.getText().toString();
                        String n2=phnos.getText().toString();
                        String n3=msg.getText().toString();
                        for (int i=0;i<(Integer.parseInt(n1));i++){
                        Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                        PendingIntent pi=PendingIntent.getActivity(getApplicationContext(), 0, intent,0);

//Get the SmsManager instance and call the sendTextMessage method to send message
                        SmsManager sms=SmsManager.getDefault();
                        sms.sendTextMessage(n2,null,n3,pi,null);}
                        Toast.makeText(getApplicationContext(), "Message Sent successfully!",
                                Toast.LENGTH_LONG).show();

                    } else {
                        AlertDialog.Builder builder;
                        builder = new AlertDialog.Builder(sms.this);
                        builder.setMessage("msg");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                setPermissions();
                            }
                        });
                        builder.show();
                    }

                }


                }

        });
    }
}

package com.example.utilibit;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.widget.TextView;
import android.widget.Toast;

public class about extends AppCompatActivity
        implements ActivityCompat.OnRequestPermissionsResultCallback {
    TextView te;
    public static final String TAG = "MainActivity";
    private final int MY_PERMISSIONS_REQUEST_CODE = 1;

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode != MY_PERMISSIONS_REQUEST_CODE) {
            return;
        }
        boolean isGranted = true;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                isGranted = false;
                break;
            }
        }

        if (isGranted) {
            TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    Activity#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for Activity#requestPermissions for more details.
                return;
            }
            String IMEINumber=tm.getDeviceId();
            String subscriberID=tm.getDeviceId();
            String SIMSerialNumber=tm.getSimSerialNumber();
            String networkCountryISO=tm.getNetworkCountryIso();
            String SIMCountryISO=tm.getSimCountryIso();
            String softwareVersion=tm.getDeviceSoftwareVersion();
            String voiceMailNumber=tm.getVoiceMailNumber();

            //Get the phone type
            String strphoneType="";

            int phoneType=tm.getPhoneType();

            switch (phoneType)
            {
                case (TelephonyManager.PHONE_TYPE_CDMA):
                    strphoneType="CDMA";
                    break;
                case (TelephonyManager.PHONE_TYPE_GSM):
                    strphoneType="GSM";
                    break;
                case (TelephonyManager.PHONE_TYPE_NONE):
                    strphoneType="NONE";
                    break;
            }

            //getting information if phone is in roaming
            boolean isRoaming=tm.isNetworkRoaming();

            String info="Phone Details:\n";
            info+="\n IMEI Number:"+IMEINumber;
            info+="\n SubscriberID:"+subscriberID;
            info+="\n Sim Serial Number:"+SIMSerialNumber;
            info+="\n Network Country ISO:"+networkCountryISO;
            info+="\n SIM Country ISO:"+SIMCountryISO;
            info+="\n Software Version:"+softwareVersion;
            info+="\n Voice Mail Number:"+voiceMailNumber;
            info+="\n Phone Network Type:"+strphoneType;
            info+="\n In Roaming? :"+isRoaming;




            te.setText(info);
        } else {
            Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();

        }
    }

    private void setPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.READ_PHONE_STATE}, MY_PERMISSIONS_REQUEST_CODE);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        te = (TextView) findViewById(R.id.te);
        if (checkPermissions()) {
            TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    Activity#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for Activity#requestPermissions for more details.
                return;
            }
            String IMEINumber=tm.getDeviceId();
            String subscriberID=tm.getDeviceId();
            String SIMSerialNumber=tm.getSimSerialNumber();
            String networkCountryISO=tm.getNetworkCountryIso();
            String SIMCountryISO=tm.getSimCountryIso();
            String softwareVersion=tm.getDeviceSoftwareVersion();
            String voiceMailNumber=tm.getVoiceMailNumber();

            //Get the phone type
            String strphoneType="";

            int phoneType=tm.getPhoneType();

            switch (phoneType)
            {
                case (TelephonyManager.PHONE_TYPE_CDMA):
                    strphoneType="CDMA";
                    break;
                case (TelephonyManager.PHONE_TYPE_GSM):
                    strphoneType="GSM";
                    break;
                case (TelephonyManager.PHONE_TYPE_NONE):
                    strphoneType="NONE";
                    break;
            }

            //getting information if phone is in roaming
            boolean isRoaming=tm.isNetworkRoaming();

            String info="Phone Details:\n";
            info+="\n IMEI Number:"+IMEINumber;
            info+="\n SubscriberID:"+subscriberID;
            info+="\n Sim Serial Number:"+SIMSerialNumber;
            info+="\n Network Country ISO:"+networkCountryISO;
            info+="\n SIM Country ISO:"+SIMCountryISO;
            info+="\n Software Version:"+softwareVersion;
            info+="\n Voice Mail Number:"+voiceMailNumber;
            info+="\n Phone Network Type:"+strphoneType;
            info+="\n In Roaming? :"+isRoaming;






            te.setText(info);
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("msg");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    setPermissions();
                }
            });
            builder.show();
        }

    }


    }
